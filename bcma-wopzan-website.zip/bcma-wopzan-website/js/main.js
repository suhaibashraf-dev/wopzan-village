// Bright Career Model Academy Wopzan — shared interactions
document.addEventListener('DOMContentLoaded', () => {

  /* ---------- loader ---------- */
  const loader = document.getElementById('loader');
  if (loader) {
    window.addEventListener('load', () => {
      setTimeout(() => loader.classList.add('hide'), 350);
    });
    // safety fallback
    setTimeout(() => loader.classList.add('hide'), 2200);
  }

  /* ---------- nav scroll state ---------- */
  const nav = document.querySelector('.nav');
  const onScroll = () => {
    if (!nav) return;
    if (window.scrollY > 40) nav.classList.add('scrolled');
    else nav.classList.remove('scrolled');
    const toTop = document.querySelector('.to-top');
    if (toTop) toTop.classList.toggle('show', window.scrollY > 700);
  };
  document.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- mobile drawer ---------- */
  const burger = document.querySelector('.nav-burger');
  const drawer = document.querySelector('.mobile-drawer');
  const drawerClose = document.querySelector('.drawer-close');
  if (burger && drawer) {
    burger.addEventListener('click', () => drawer.classList.add('open'));
    drawerClose && drawerClose.addEventListener('click', () => drawer.classList.remove('open'));
    drawer.querySelectorAll('a').forEach(a => a.addEventListener('click', () => drawer.classList.remove('open')));
  }

  /* ---------- active nav link ---------- */
  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .mobile-drawer nav a').forEach(a => {
    if (a.getAttribute('href') === path) a.classList.add('active');
  });

  /* ---------- scroll reveal ---------- */
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('in'));
  }

  /* ---------- animated counters ---------- */
  const counters = document.querySelectorAll('[data-count]');
  const animateCount = (el) => {
    const target = parseFloat(el.dataset.count);
    const suffix = el.dataset.suffix || '';
    const dur = 1600;
    const start = performance.now();
    const step = (t) => {
      const p = Math.min((t - start) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      const val = target < 20 && target % 1 !== 0 ? (target * eased).toFixed(1) : Math.floor(target * eased);
      el.textContent = val + suffix;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };
  if ('IntersectionObserver' in window && counters.length) {
    const co = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) { animateCount(e.target); co.unobserve(e.target); } });
    }, { threshold: 0.4 });
    counters.forEach(c => co.observe(c));
  }

  /* ---------- hero parallax ---------- */
  const heroMedia = document.querySelector('.hero-media img');
  if (heroMedia) {
    window.addEventListener('scroll', () => {
      const y = Math.min(window.scrollY, 700);
      heroMedia.style.transform = `scale(1.06) translateY(${y * 0.15}px)`;
    }, { passive: true });
  }

  /* ---------- gallery filter ---------- */
  const chips = document.querySelectorAll('.filter-chip');
  const items = document.querySelectorAll('.masonry-item');
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      const f = chip.dataset.filter;
      items.forEach(it => {
        const show = f === 'all' || it.dataset.cat === f;
        it.style.display = show ? '' : 'none';
      });
    });
  });

  /* ---------- lazy load images ---------- */
  document.querySelectorAll('img[loading="lazy"]').forEach(img => {
    if (img.complete) img.classList.add('loaded');
    else img.addEventListener('load', () => img.classList.add('loaded'));
  });

  /* ---------- lightbox ---------- */
  const lightbox = document.getElementById('lightbox');
  if (lightbox) {
    const lbImg = lightbox.querySelector('img');
    const lbCaption = lightbox.querySelector('.lightbox-caption');
    const gallery = Array.from(document.querySelectorAll('.masonry-item img'));
    let idx = 0;
    const open = (i) => {
      idx = i;
      lbImg.src = gallery[idx].src;
      lbCaption.textContent = gallery[idx].alt || '';
      lightbox.classList.add('open');
    };
    document.querySelectorAll('.masonry-item').forEach((el, i) => {
      el.addEventListener('click', () => open(i));
    });
    lightbox.querySelector('.lightbox-close').addEventListener('click', () => lightbox.classList.remove('open'));
    lightbox.querySelector('.lightbox-next').addEventListener('click', () => open((idx + 1) % gallery.length));
    lightbox.querySelector('.lightbox-prev').addEventListener('click', () => open((idx - 1 + gallery.length) % gallery.length));
    lightbox.addEventListener('click', (e) => { if (e.target === lightbox) lightbox.classList.remove('open'); });
    document.addEventListener('keydown', (e) => {
      if (!lightbox.classList.contains('open')) return;
      if (e.key === 'Escape') lightbox.classList.remove('open');
      if (e.key === 'ArrowRight') open((idx + 1) % gallery.length);
      if (e.key === 'ArrowLeft') open((idx - 1 + gallery.length) % gallery.length);
    });
  }

  /* ---------- FAQ accordion ---------- */
  document.querySelectorAll('.faq-item').forEach(item => {
    const q = item.querySelector('.faq-q');
    q && q.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!isOpen) item.classList.add('open');
    });
  });

  /* ---------- simple contact/admission form feedback (no backend wired) ---------- */
  document.querySelectorAll('form[data-demo-form]').forEach(f => {
    f.addEventListener('submit', (e) => {
      e.preventDefault();
      const btn = f.querySelector('button[type=submit]');
      const original = btn.textContent;
      btn.textContent = 'Sending…';
      setTimeout(() => {
        btn.textContent = 'Received ✓';
        f.reset();
        setTimeout(() => btn.textContent = original, 2200);
      }, 900);
    });
  });

});
