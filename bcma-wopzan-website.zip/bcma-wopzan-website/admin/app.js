/* =============================================================================
   BCMA Wopzan — Admin Dashboard logic (DEMO MODE)
   ---------------------------------------------------------------------------
   This file uses window.localStorage as a stand-in database so the dashboard
   is fully interactive out of the box, with no setup required.

   TO CONNECT REAL FIREBASE (see admin/README-FIREBASE.md for full steps):
   1. Add the Firebase SDK + your project's config in index.html <head>.
   2. Replace the `db` object below with calls to Firebase Auth / Firestore /
      Storage. Every function below is written as `db.<collection>.get/set()`
      on purpose, so you can swap the internals for Firestore calls
      (getDocs/addDoc/updateDoc/deleteDoc, or onSnapshot for live sync)
      without touching the UI code that calls them.
   3. Replace checkLogin() with firebase.auth().signInWithEmailAndPassword().
   4. Replace the gallery file input handler with an upload to Firebase
      Storage, then save the returned download URL into Firestore.
   ============================================================================= */

// ---- tiny localStorage-backed "database" (swap for Firestore later) ----
const db = {
  _key: (col) => `bcma_admin_${col}`,
  get(col, fallback = []) {
    try {
      const raw = localStorage.getItem(this._key(col));
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) { return fallback; }
  },
  set(col, value) {
    localStorage.setItem(this._key(col), JSON.stringify(value));
  }
};

// ---- seed demo data on first run ----
function seed() {
  if (!localStorage.getItem('bcma_admin_seeded')) {
    db.set('gallery', [
      { id: 1, caption: 'Front view of the academy', cat: 'campus', img: '../assets/img/campus-1.svg' },
      { id: 2, caption: 'Smart classroom in session', cat: 'classrooms', img: '../assets/img/classroom-1.svg' },
      { id: 3, caption: 'Annual sports day', cat: 'sports', img: '../assets/img/sports-2.svg' },
    ]);
    db.set('notices', [
      { id: 1, date: '2026-03-18', cat: 'Admission', title: 'Admissions Open for 2026-27', desc: 'Registrations now open for Nursery to Class 8.' },
      { id: 2, date: '2026-04-02', cat: 'Event', title: 'Annual Cultural & Prize Day - April 5', desc: 'All parents are invited to the annual prize evening.' },
    ]);
    db.set('admissions', [
      { id: 1, name: 'Ayesha Bhat', cls: 'Class 2', parent: 'Rafiqa Jan', phone: '+91 90xxxxxx01', status: 'new' },
      { id: 2, name: 'Umar Rather', cls: 'Nursery', parent: 'Manzoor Ahmad', phone: '+91 90xxxxxx02', status: 'pending' },
    ]);
    db.set('events', [
      { id: 1, date: '2026-06-12', title: 'Summer Sports Meet', desc: 'Track, field and team events for all classes.' },
      { id: 2, date: '2026-08-15', title: 'Independence Day', desc: 'Flag hoisting and cultural programme.' },
    ]);
    db.set('teachers', [
      { id: 1, name: 'Fayaz Ahmad Rather', role: 'Principal' },
      { id: 2, name: 'Fayaz Ahmad Bhat', role: 'Chairman' },
    ]);
    db.set('homepage', { tagline: 'Enter to Learn, Leave to Serve', desc: "Bright Career Model Academy Wopzan builds academic excellence, language, discipline and quiet confidence in every child.", stat1: '8+', stat2: '500+', stat3: '30+', stat4: '100%' });
    db.set('contact', { phone: '+91 7889881993', email: 'bcmaopzan@gmail.com', address: 'Wopzan, Tehsil Bijbehara, District Anantnag, Jammu & Kashmir – 192124', map: 'https://maps.app.goo.gl/4o1v1BE1aUDT7fJq8' });
    db.set('announcement', { text: '', active: false });
    localStorage.setItem('bcma_admin_seeded', '1');
  }
}
seed();

// ---- auth gate (DEMO — swap for firebase.auth()) ----
const DEMO_EMAIL = 'admin@bcmawopzan.edu.in';
const DEMO_PASS = 'bcma2026';
const loginScreen = document.getElementById('loginScreen');
const dashboardShell = document.getElementById('dashboardShell');

function checkLogin() {
  if (sessionStorage.getItem('bcma_admin_authed') === '1') {
    loginScreen.style.display = 'none';
    dashboardShell.style.display = 'grid';
    renderAll();
  }
}
checkLogin();

document.getElementById('loginForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim();
  const pass = document.getElementById('loginPass').value;
  const err = document.getElementById('loginError');
  if (email === DEMO_EMAIL && pass === DEMO_PASS) {
    sessionStorage.setItem('bcma_admin_authed', '1');
    err.style.display = 'none';
    checkLogin();
  } else {
    err.style.display = 'block';
  }
});
document.getElementById('signOutBtn').addEventListener('click', () => {
  sessionStorage.removeItem('bcma_admin_authed');
  location.reload();
});

// ---- panel routing ----
const navLinks = document.querySelectorAll('.admin-nav a');
const panels = document.querySelectorAll('.admin-panel');
const titles = {
  dashboard: ['Dashboard', 'Overview of school activity'],
  homepage: ['Homepage', 'Edit the content shown on the public homepage hero'],
  gallery: ['Gallery', 'Upload and manage photo gallery images'],
  notices: ['Notice Board', 'Publish notices for parents and students'],
  admissions: ['Admissions', 'Review and manage admission enquiries'],
  events: ['Events', 'Manage the school events calendar'],
  teachers: ['Teachers', 'Manage faculty listed on the website'],
  announcements: ['Announcements', 'Control the site-wide announcement banner'],
  contact: ['Contact Info', 'Update the school\'s public contact details'],
};
function showPanel(name) {
  panels.forEach(p => p.classList.toggle('active', p.dataset.panel === name));
  navLinks.forEach(a => a.classList.toggle('active', a.dataset.panel === name));
  document.getElementById('panelTitle').textContent = titles[name][0];
  document.getElementById('panelSub').textContent = titles[name][1];
  document.getElementById('adminSide').classList.remove('open');
}
navLinks.forEach(a => a.addEventListener('click', (e) => {
  e.preventDefault();
  showPanel(a.dataset.panel);
}));
window.addEventListener('hashchange', () => {
  const name = location.hash.replace('#', '');
  if (titles[name]) showPanel(name);
});
if (titles[location.hash.replace('#', '')]) showPanel(location.hash.replace('#', ''));

const flash = () => {
  const el = document.getElementById('saveIndicator');
  el.textContent = 'Saved ✓';
  el.style.background = '#e9f3ea'; el.style.color = '#2f4a3e';
  setTimeout(() => { el.textContent = 'All changes saved locally'; el.style.background = ''; el.style.color = ''; }, 1600);
};

// ---- render everything ----
function renderAll() {
  renderDashboard();
  renderGallery();
  renderNotices();
  renderAdmissions();
  renderEvents();
  renderTeachers();
  loadHomepageForm();
  loadContactForm();
  loadAnnounceForm();
}

function renderDashboard() {
  document.getElementById('statGallery').textContent = db.get('gallery').length;
  document.getElementById('statNotices').textContent = db.get('notices').length;
  document.getElementById('statAdmissions').textContent = db.get('admissions').length;
  document.getElementById('statEvents').textContent = db.get('events').length;
  const rows = db.get('admissions').slice(-5).reverse().map(a => `
    <tr><td>${a.name}</td><td>${a.cls}</td><td>${a.phone}</td>
    <td><span class="chip-status ${a.status}">${a.status}</span></td></tr>`).join('');
  document.getElementById('dashAdmissionsPreview').innerHTML = rows || '<tr><td colspan="4" style="color:var(--ink-500)">No enquiries yet.</td></tr>';
}

// ---- GALLERY ----
function renderGallery() {
  const items = db.get('gallery');
  document.getElementById('galleryTable').innerHTML = items.map(g => `
    <tr>
      <td><img src="${g.img}" alt="" style="width:52px;height:40px;object-fit:cover;border-radius:6px"></td>
      <td>${g.caption}</td><td><span class="pill">${g.cat}</span></td>
      <td><button class="icon-btn" data-del-gallery="${g.id}" aria-label="Delete">✕</button></td>
    </tr>`).join('') || '<tr><td colspan="4" style="color:var(--ink-500)">No images yet.</td></tr>';
  renderDashboard();
}
document.getElementById('galleryForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const items = db.get('gallery');
  const fileInput = document.getElementById('g_file');
  // DEMO: use a local object URL as a stand-in preview.
  // REAL FIREBASE: upload fileInput.files[0] to Storage, then store the
  // returned download URL here instead of an objectURL.
  const previewUrl = fileInput.files[0] ? URL.createObjectURL(fileInput.files[0]) : '../assets/img/campus-1.svg';
  items.push({ id: Date.now(), caption: document.getElementById('g_caption').value, cat: document.getElementById('g_cat').value, img: previewUrl });
  db.set('gallery', items);
  e.target.reset();
  renderGallery(); flash();
});
document.getElementById('galleryTable').addEventListener('click', (e) => {
  const id = e.target.dataset.delGallery;
  if (id) { db.set('gallery', db.get('gallery').filter(g => g.id != id)); renderGallery(); flash(); }
});

// ---- NOTICES ----
function renderNotices() {
  const items = db.get('notices').slice().reverse();
  document.getElementById('noticeTable').innerHTML = items.map(n => `
    <tr><td>${n.date}</td><td><span class="pill">${n.cat}</span></td><td>${n.title}</td>
    <td><button class="icon-btn" data-del-notice="${n.id}" aria-label="Delete">✕</button></td></tr>`).join('')
    || '<tr><td colspan="4" style="color:var(--ink-500)">No notices yet.</td></tr>';
  renderDashboard();
}
document.getElementById('noticeForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const items = db.get('notices');
  items.push({ id: Date.now(), date: new Date().toISOString().slice(0,10), cat: document.getElementById('n_cat').value, title: document.getElementById('n_title').value, desc: document.getElementById('n_desc').value });
  db.set('notices', items); e.target.reset(); renderNotices(); flash();
});
document.getElementById('noticeTable').addEventListener('click', (e) => {
  const id = e.target.dataset.delNotice;
  if (id) { db.set('notices', db.get('notices').filter(n => n.id != id)); renderNotices(); flash(); }
});

// ---- ADMISSIONS ----
function renderAdmissions() {
  const items = db.get('admissions').slice().reverse();
  document.getElementById('admissionsTable').innerHTML = items.map(a => `
    <tr><td>${a.name}</td><td>${a.cls}</td><td>${a.parent}</td><td>${a.phone}</td>
    <td><select data-status="${a.id}"><option value="new" ${a.status==='new'?'selected':''}>New</option><option value="pending" ${a.status==='pending'?'selected':''}>Pending</option><option value="admitted" ${a.status==='admitted'?'selected':''}>Admitted</option></select></td>
    <td><button class="icon-btn" data-del-adm="${a.id}" aria-label="Delete">✕</button></td></tr>`).join('')
    || '<tr><td colspan="6" style="color:var(--ink-500)">No enquiries yet.</td></tr>';
  renderDashboard();
}
document.getElementById('admissionsTable').addEventListener('change', (e) => {
  const id = e.target.dataset.status;
  if (id) {
    const items = db.get('admissions').map(a => a.id == id ? { ...a, status: e.target.value } : a);
    db.set('admissions', items); flash();
  }
});
document.getElementById('admissionsTable').addEventListener('click', (e) => {
  const id = e.target.dataset.delAdm;
  if (id) { db.set('admissions', db.get('admissions').filter(a => a.id != id)); renderAdmissions(); flash(); }
});

// ---- EVENTS ----
function renderEvents() {
  const items = db.get('events').slice().sort((a,b) => a.date.localeCompare(b.date));
  document.getElementById('eventsTable').innerHTML = items.map(ev => `
    <tr><td>${ev.date}</td><td>${ev.title}</td><td>${ev.desc || ''}</td>
    <td><button class="icon-btn" data-del-event="${ev.id}" aria-label="Delete">✕</button></td></tr>`).join('')
    || '<tr><td colspan="4" style="color:var(--ink-500)">No events yet.</td></tr>';
  renderDashboard();
}
document.getElementById('eventForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const items = db.get('events');
  items.push({ id: Date.now(), date: document.getElementById('e_date').value, title: document.getElementById('e_title').value, desc: document.getElementById('e_desc').value });
  db.set('events', items); e.target.reset(); renderEvents(); flash();
});
document.getElementById('eventsTable').addEventListener('click', (e) => {
  const id = e.target.dataset.delEvent;
  if (id) { db.set('events', db.get('events').filter(ev => ev.id != id)); renderEvents(); flash(); }
});

// ---- TEACHERS ----
function renderTeachers() {
  const items = db.get('teachers');
  document.getElementById('teachersTable').innerHTML = items.map(t => `
    <tr><td>${t.name}</td><td>${t.role}</td>
    <td><button class="icon-btn" data-del-teacher="${t.id}" aria-label="Delete">✕</button></td></tr>`).join('')
    || '<tr><td colspan="3" style="color:var(--ink-500)">No teachers added yet.</td></tr>';
}
document.getElementById('teacherForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const items = db.get('teachers');
  items.push({ id: Date.now(), name: document.getElementById('t_name').value, role: document.getElementById('t_role').value });
  db.set('teachers', items); e.target.reset(); renderTeachers(); flash();
});
document.getElementById('teachersTable').addEventListener('click', (e) => {
  const id = e.target.dataset.delTeacher;
  if (id) { db.set('teachers', db.get('teachers').filter(t => t.id != id)); renderTeachers(); flash(); }
});

// ---- HOMEPAGE ----
function loadHomepageForm() {
  const h = db.get('homepage', {});
  document.getElementById('hp_tagline').value = h.tagline || '';
  document.getElementById('hp_desc').value = h.desc || '';
  document.getElementById('hp_stat1').value = h.stat1 || '';
  document.getElementById('hp_stat2').value = h.stat2 || '';
  document.getElementById('hp_stat3').value = h.stat3 || '';
  document.getElementById('hp_stat4').value = h.stat4 || '';
}
document.getElementById('homepageForm').addEventListener('submit', (e) => {
  e.preventDefault();
  db.set('homepage', {
    tagline: document.getElementById('hp_tagline').value,
    desc: document.getElementById('hp_desc').value,
    stat1: document.getElementById('hp_stat1').value,
    stat2: document.getElementById('hp_stat2').value,
    stat3: document.getElementById('hp_stat3').value,
    stat4: document.getElementById('hp_stat4').value,
  });
  flash();
});

// ---- CONTACT ----
function loadContactForm() {
  const c = db.get('contact', {});
  document.getElementById('c_phone').value = c.phone || '';
  document.getElementById('c_email').value = c.email || '';
  document.getElementById('c_address').value = c.address || '';
  document.getElementById('c_map').value = c.map || '';
}
document.getElementById('contactForm').addEventListener('submit', (e) => {
  e.preventDefault();
  db.set('contact', {
    phone: document.getElementById('c_phone').value,
    email: document.getElementById('c_email').value,
    address: document.getElementById('c_address').value,
    map: document.getElementById('c_map').value,
  });
  flash();
});

// ---- ANNOUNCEMENT ----
function loadAnnounceForm() {
  const a = db.get('announcement', {});
  document.getElementById('a_text').value = a.text || '';
  document.getElementById('a_active').checked = !!a.active;
}
document.getElementById('announceForm').addEventListener('submit', (e) => {
  e.preventDefault();
  db.set('announcement', { text: document.getElementById('a_text').value, active: document.getElementById('a_active').checked });
  flash();
});
