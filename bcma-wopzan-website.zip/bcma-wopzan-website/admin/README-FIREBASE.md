# Connecting the Admin Dashboard to Firebase

The admin dashboard (`/admin/index.html` + `/admin/app.js`) currently runs in
**demo mode**: it stores everything in the browser (`localStorage`), so you
can click around and see the full interface immediately, with no setup.

To make it a real, secure backend, follow these steps.

## 1. Create a Firebase project
1. Go to https://console.firebase.google.com and create a project (e.g. `bcma-wopzan`).
2. Enable **Authentication** → Email/Password sign-in method.
3. Enable **Firestore Database** (start in production mode).
4. Enable **Storage** (for gallery image uploads).
5. Create your admin user under Authentication → Users (this replaces the
   demo `admin@bcmawopzan.edu.in` / `bcma2026` login).

## 2. Add the Firebase SDK
In `admin/index.html`, add before `</head>`:
```html
<script type="module">
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.x/firebase-app.js";
  import { getAuth } from "https://www.gstatic.com/firebasejs/10.x/firebase-auth.js";
  import { getFirestore } from "https://www.gstatic.com/firebasejs/10.x/firebase-firestore.js";
  import { getStorage } from "https://www.gstatic.com/firebasejs/10.x/firebase-storage.js";

  const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    projectId: "YOUR_PROJECT",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "...",
    appId: "..."
  };
  const app = initializeApp(firebaseConfig);
  window.auth = getAuth(app);
  window.firestore = getFirestore(app);
  window.storage = getStorage(app);
</script>
```
Copy the exact `firebaseConfig` values from Project Settings → General → Your apps.

## 3. Replace the demo pieces in `app.js`
- **Login**: swap `checkLogin()` / the login form handler for
  `signInWithEmailAndPassword(auth, email, pass)`.
- **Data (`db` object)**: swap each `db.get/set(collection, ...)` call for
  Firestore's `getDocs`, `addDoc`, `updateDoc`, `deleteDoc` on a collection
  of the same name (`gallery`, `notices`, `admissions`, `events`, `teachers`,
  `homepage`, `contact`, `announcement`). The UI code that calls these
  functions does not need to change.
- **Gallery uploads**: in the gallery form handler, upload
  `fileInput.files[0]` to Firebase Storage with `uploadBytes`, then call
  `getDownloadURL()` and save that URL into the Firestore `gallery` document
  instead of the temporary `URL.createObjectURL(...)` preview used in demo mode.

## 4. Secure your data with Firestore rules
At minimum:
```
match /admissions/{doc} {
  allow read, write: if request.auth != null;
}
match /{collection}/{doc} {
  allow read: if true;              // public site can read notices, gallery, etc.
  allow write: if request.auth != null;  // only signed-in admins can write
}
```

## 5. Connect the public site (optional next step)
Right now the public pages (`index.html`, `notice-board.html`, `gallery.html`,
etc.) use static content. Once your Firestore collections are live, you can
fetch them with `getDocs()`/`onSnapshot()` on page load and render notices,
gallery images and events dynamically, so anything you publish from the
admin dashboard appears on the live site automatically.
